const config = {
	proxy: 'http://gulp-new.test',
	host: 'gulp-new.test',
	open: 'external',
};
const tinyPngKey = '';


const {src, dest, parallel, series, watch} = require('gulp');
const sass = require('gulp-sass');
const notify = require('gulp-notify');
const autoprefixer = require('gulp-autoprefixer');
const cleanCSS = require('gulp-clean-css');
const sourcemaps = require('gulp-sourcemaps');
const browserSync = require('browser-sync').create();
const ttf2woff = require('gulp-ttf2woff');
const ttf2woff2 = require('gulp-ttf2woff2');
const del = require('del');
const webpack = require('webpack');
const webpackStream = require('webpack-stream');
const uglify = require('gulp-uglify-es').default;
const tiny = require('gulp-tinypng-compress');
const imagemin = require('gulp-imagemin');


const fonts = () => {
	src(['./src/fonts/**.ttf', './src/fonts/**.otf', './src/fonts/**.woff', './src/fonts/**.woff2', './src/fonts/**.eot', './src/fonts/**.svg'])
		.pipe(dest('./fonts/'))
	src('./src/fonts/**.ttf')
		.pipe(ttf2woff())
		.pipe(dest('./fonts/'))
	return src('./src/fonts/**.ttf')
		.pipe(ttf2woff2())
		.pipe(dest('./fonts/'))
}

const styles = () => {
	return src('./scss/**/*.scss')
		.pipe(sourcemaps.init())
		.pipe(sass({
			outputStyle: 'compact'
		}).on('error', notify.onError()))
		.pipe(autoprefixer({
			cascade: false,
		}))
		.pipe(sourcemaps.write('.'))
		.pipe(dest('./'))
		.pipe(browserSync.stream());
}


const imgToApp = () => {
	return src(['./src/images/**.jpg', './src/images/**.png', './src/images/**.jpeg', './src/images/**.svg'])
		.pipe(dest('./images'))
}

const clean = () => {
	return del(['images', 'fonts', 'js', 'style.css', 'style.css.map'])
}

const scripts = () => {
	src('./src/js/jquery.main.js')
		.pipe(dest('./js'))
	return src('./src/js/main.js')
		.pipe(webpackStream({
			mode: 'development',
			output: {
				filename: 'main.js',
			},
			module: {
				rules: [{
					test: /\.m?js$/,
					exclude: /(node_modules|bower_components)/,
					use: {
						loader: 'babel-loader',
						options: {
							presets: ['@babel/preset-env']
						}
					}
				}]
			},
		}))
		.on('error', function (err) {
			console.error('WEBPACK ERROR', err);
			this.emit('end'); // Don't stop the rest of the task
		})

		.pipe(sourcemaps.init())
		.pipe(uglify().on("error", notify.onError()))
		.pipe(sourcemaps.write('.'))
		.pipe(dest('./js'))
		.pipe(browserSync.stream());
}

const watchFiles = () => {
	browserSync.init(config);

	watch('./scss/**/*.scss', styles);
	watch('./src/images/**.jpg', imgToApp);
	watch('./src/images/**.png', imgToApp);
	watch('./src/images/**.jpeg', imgToApp);
	watch('./src/images/**.svg', imgToApp);
	watch('./src/fonts/**.ttf', fonts);
	watch('./src/js/**/*.js', scripts);
}

const tinypng = () => {
	src('./src/images/**.svg')
		.pipe(dest('./images'))
	return src(['./src/images/**.jpg', './src/images/**.png', './src/images/**.jpeg'])
		.pipe(tiny({
			key: tinyPngKey,
			log: true
		}))
		.pipe(dest('./images'))
}

const imageMin = () => {
	src('./src/images/**.svg')
		.pipe(dest('./images'))
	return src(['./src/images/**.jpg', './src/images/**.png', './src/images/**.jpeg'])
		.pipe(imagemin())
		.pipe(dest('./images'))
}

const stylesBuild = () => {
	return src('./scss/**/*.scss')
		.pipe(sass({
			outputStyle: 'compact'
		}).on('error', notify.onError()))
		.pipe(autoprefixer({
			cascade: false,
		}))
		.pipe(dest('./'))
}

const stylesDist = () => {
	return src('./scss/**/*.scss')
		.pipe(sass({
			outputStyle: 'compact'
		}).on('error', notify.onError()))
		.pipe(autoprefixer({
			cascade: false,
		}))
		.pipe(cleanCSS({
			level: 2
		}))
		.pipe(dest('./'))
}

const scriptsBuild = () => {
	src('./src/js/jquery.main.js')
		.pipe(dest('./js'))
	return src('./src/js/main.js')
		.pipe(webpackStream({
			mode: 'development',
			output: {
				filename: 'main.js',
			},
			module: {
				rules: [{
					test: /\.m?js$/,
					exclude: /(node_modules|bower_components)/,
					use: {
						loader: 'babel-loader',
						options: {
							presets: ['@babel/preset-env']
						}
					}
				}]
			},
		}))
		.on('error', function (err) {
			console.error('WEBPACK ERROR', err);
			this.emit('end'); // Don't stop the rest of the task
		})
		.pipe(uglify().on("error", notify.onError()))
		.pipe(dest('./js'))
}

exports.styles = styles;
exports.watchFiles = watchFiles;

exports.default = series(clean, parallel(scripts, fonts, imgToApp), styles, watchFiles);
exports.build = series(clean, parallel(scriptsBuild, fonts, imgToApp), stylesBuild, imageMin);
exports.min = series(clean, parallel(scriptsBuild, fonts, imgToApp), stylesDist); // tinypng

